#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/workspace/dist/lib"
XSLT_LIBS="-lxslt  -lxml2 -lm "
XSLT_INCLUDEDIR="-I/workspace/dist/include"
MODULE_VERSION="xslt-1.1.28"
